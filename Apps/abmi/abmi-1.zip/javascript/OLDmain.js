var invalidPop="#invalid";var slide={transition:"slideup"};var answerOne="#answerPop";function bmiE(x,y){var x;var y;x=document.getElementById('height');y=document.getElementById('weight');var xSelect=selector.options[selector.options.selectedIndex].value;if(isNaN(x.value&&y.value)){$.mobile.changePage(invalidPop,slide);return false}if(x.value===""||x.value===null){$.mobile.changePage(invalidPop,slide);return false}if(y.value===""||y.value===null){$.mobile.changePage(invalidPop,slide);return false}if(xSelect==="metric"){answer=y.value/Math.pow(x.value,2)}if(xSelect==="metric2"){answer=y.value/Math.pow((x.value/100),2)}if(xSelect==="eng"){answer=[y.value/Math.pow(x.value,2)]*703}$.mobile.changePage(answerOne,slide);document.getElementById('answer').innerHTML=Math.round(answer*100)/100;if(answer<=15.99){document.getElementById('answerOut').innerHTML="Severe Thinness";return false}if(answer>=16.00&&answer<=16.99){document.getElementById('answerOut').innerHTML="Moderate Thinness";return false}if(answer>=17.00&&answer<=18.49){document.getElementById('answerOut').innerHTML="Mild Thinness";return false}if(answer>=18.50&&answer<=24.99){document.getElementById('answerOut').innerHTML="Normal Weight";return false}if(answer>=25.00&&answer<=29.99){document.getElementById('answerOut').innerHTML="Overweight";return false}if(answer>=30.00&&answer<=34.99){document.getElementById('answerOut').innerHTML="Obese Class I";return false}if(answer>=35.00&&answer<=39.99){document.getElementById('answerOut').innerHTML="Obese Class II";return false}if(answer>=40.0){document.getElementById('answerOut').innerHTML="Obese Class III";return false}}

var installer = function() {
	// Install app
	if (navigator.mozApps) {
	    var checkIfInstalled = navigator.mozApps.getSelf();
	    checkIfInstalled.onsuccess = function () {
	        if (checkIfInstalled.result) {
	            // Already installed
	        }
	        else {
	            var install = document.querySelector("#install"),
	                manifestURL = location.href.substring(0, location.href.lastIndexOf("/")) + "/manifest.webapp";
	                alert(manifestURL);
	            //install.parentNode.className = "show-install";
				install.style.display = "block";
	            install.onclick = function () {
	                var installApp = navigator.mozApps.install(manifestURL);
	                installApp.onsuccess = function(data) {
	                    install.style.display = "none";
	                };
	                installApp.onerror = function() {
	                    alert("Install failed\n\n:" + installApp.error.name);
	                };
	            };
	        }
	    };
	}
	else {
	    console.log("Open Web Apps not supported");
	}
		
};

//=====================DOCUMENT READY!!!  ===============================================================================  
$(document).ready(function() {
  	//time to load, lets go!
	//installer();
});