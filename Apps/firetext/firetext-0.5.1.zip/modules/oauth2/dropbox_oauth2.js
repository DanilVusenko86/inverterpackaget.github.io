// Launch OAuth Receiver with internal app flag
Dropbox.AuthDriver.FFOSPopup.oauthReceiver(true);