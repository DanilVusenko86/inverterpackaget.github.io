window.addEventListener("load", function() {
  console.log("Hello World!");
});
